from django.apps import AppConfig


class CreatorProgramConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'creator_program'
    verbose_name = 'مدیریت طرح‌ها'