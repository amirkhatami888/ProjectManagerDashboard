from django.apps import AppConfig


class CreatorProjectConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "creator_project"
