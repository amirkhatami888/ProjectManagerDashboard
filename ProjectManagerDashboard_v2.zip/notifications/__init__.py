default_app_config = 'notifications.apps.NotificationsConfig'
