from project_dashboard.wsgi import application
