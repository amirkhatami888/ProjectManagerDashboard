from django.apps import AppConfig


class NotificationsSmsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "notifications_sms"
