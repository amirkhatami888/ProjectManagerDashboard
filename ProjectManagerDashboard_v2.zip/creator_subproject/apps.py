from django.apps import AppConfig


class CreatorSubprojectConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "creator_subproject"
